#forensic tool by black security
#enigma
#unix password cracker
import os
import crypt
from colored import *
from time import *
print '%s Loading Unix Cracker Module%s' % (fg(3), attr(0))
sleep(4)
print '\n[+] Configuring directory for userfiles.'
sleep(3)
print '[+] Reading pass phrase list.\n'
sleep(3)
try:	
	def testPass(cryptPass):
		salt = cryptPass[0:2]
		dictFile = open(str(raw_input('USER: ')),'r')		#ename your user list to "userfile.list"
		for word in dictFile.readlines():
				word = word.strip('\n')
				cryptWord = crypt.crypt(word,salt)
				if (cryptWord == cryptPass):
					print "%s[+] Found Password: %s" % (fg(2), attr(0))+word+"\n"
					return
		print "%s[-] Password Not Found.%s" % (fg(1), attr(0))+'\n'
		return
	def main():
		passList = open('credentials/password.list')			#rename your password list to "password.list"
		for line in passList.readlines():
			if ":" in line:
					user = line.split(':')[0]
					cryptPass = line.split(':')[1].strip(' ')
					print "%s[*] Cracking Password For: %s" % (fg(17), attr(0))+user
					testPass(cryptPass)
	if __name__ == '__main__':
		main()
except KeyboardInterrupt:
	print (fore.RED+"\n\n[+] Interrupted!\n"+style.RESET)
	sleep(2)
except Exception, error: #handle exceptions
    	#log(error)
    	print "[-] Error Found: "+ str(error)+"\n"

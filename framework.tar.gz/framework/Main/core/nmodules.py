#!/usr/bin/python
import os
from colored import *
def nmodules():
	print "\n\t\033[1;31mUpcoming Updates\tDescription\n\033[1;m"
	print "\t\033[1;32mBluetooth Tools\033[1;m\t\tProbably some bluetooth bugging \n\t\t\t\tand vulnerability assessment tool."
	print "\t\033[1;32mSecure Shell Botnet\033[1;m\tStill researching about this one.\n\t\t\t\tTo much excitement. "
	print "\t\033[1;32mForensic Tools\033[1;m\t\tThis is very helpful for some recovery\n\t\t\t\tand research work." 
	print "\t\033[1;32mDDOS Tracker\033[1;m\t\tLet's start the hunting season. \n\t\t\t\tGood for some defensive attack."
	print "\t\033[1;32mExploitation Tools\033[1;m\tEmbed some Metasploit Framework exploit\n\t\t\t\tto automate attack.\n"

	print "\tVisit our website for some cool updates at"+fore.LIGHT_BLUE+" http://www.fsecurity.org\n"+style.RESET

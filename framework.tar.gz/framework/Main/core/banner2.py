#!/usr/bin/python
import os
from time import *
from colored import *
def banner2():

	print fore.GREEN+"" 
	print"		                 ,,.::::::::::..,        		"
	print"		             ,,::::::::::::::::::::.,			"
	print"		          ,::::::::'''	  ''':;::::;;::.		"
	print"		        ,;::::::''            ':::::;:::.		"
	print"		       .::::::::..          ..:::::;::;'		"
	print"		        ':::::::::::'    ..::::;::::;''   		"
	print"		          '::::::.''  ..::::::;:;''				"
	print"		                   ..:::::::;;''             	"	 
	print"		                 .:::::::;''					"
	print"		                .::::::;'						"
	print"		               .::::::; 						"
	print"		              ..:::::::':...       				"
	print"		               .:::::::::::;.      				"
	print"		                 .:::::::;''  					"
	print""
	print"		                   ..::::..         			"
	print"		                 ..::::::::. 					"
	print"		                ..::::::::::....      			"
	print"		                 ':::::::::'        			"
	print"		                   .:::::.            			"
	print""
	print"		            fsecurity est. 2015            "
	print""+style.RESET
	print "\t   If you're a novice, type "+('%s\"help\"%s' % (fg(1), attr(0))) +" to enlighten your brain"

	print "\t     ["+"\033[1;31mCode like a hacker and think like a fundamentalist\033[1;m"+"]\n"
	sleep(4)
	  

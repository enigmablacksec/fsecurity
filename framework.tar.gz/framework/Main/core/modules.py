#!/usr/bin/python

import os

def modules():
	print "\n\t\033[1;31mAvailable Modules\tDescription\033[1;m\n\tnet/cookiehijack\tSteal cookies stored during browsing session.\n\tnet/ftpscanner\t\tFTP Server port scanner.\n\tnet/networksniffer\tWireless traffic sniffing tool.\n\tnet/scapyscan\t\tPrint IP address and TTL of incoming packets.\n\tnet/probesniffer\tListening for 802.11 probe requests.\n\tnet/nmapinteg\t\tIntegrated port scanner with Nmap.\n\twifi/sniffhidden\tDe-cloaking hidden 802.11 networks.\n\twifi/creditcardsniff\tCredit Card credential sniffer.\n\tserver/servercomprom\tExploitaion module for FTP web pages.\n\tfile/zipfilecracker\tZip file password cracker.\n\tweb/anonbrowser\t\tAnonymously browse the web.\n\tweb/confickerdetect\tAnalyze packet capture file.\n\tweb/fastfluxdetect\tPrint stored IP in capture file.\n\tweb/iplocate\t\tGeolocate target host.\n"

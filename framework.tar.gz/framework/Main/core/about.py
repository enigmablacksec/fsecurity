#!/usr/bin/python

import os
from colored import *

def about():
	print fore.BLUE+'   FSECURITY FRAMEWORK\n'
	print fore.GREEN+'   There is no patch to human\n   stupidity - fsecurity.org\n'+style.RESET 
	print '    Version: 3.1.5' 
	print ' Build Date: May 11 2016'
	print '  Code Name: \'Parakeet\'\n'+style.RESET

	license = str(raw_input(fore.YELLOW+'   View License [Y|N] '+style.RESET))
	if (license == 'Y') | (license == 'y'):
		print " "
		os.system('cat Main/license/license.txt')
		print " "
	else:
		pass

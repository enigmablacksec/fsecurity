#!/bin/bash
# Proper header for a Bash script.
# Cleaner
# Run as root
LOG_DIR=/var/log
asul="\033[1;34m"
# Variables are better than hard-coded values.
cd $LOG_DIR
cat /dev/null > messages
cat /dev/null > wtmp
echo "[+] Logs cleaned up. No more rogue process."
exit # The right and proper method of "exiting" from a script.



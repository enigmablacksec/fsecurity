#!/usr/bin/env python
#
#fsecurity framework upgrader
#enigma
#enigma@gmail.com
#Current: Mediafire [Soon were on GitHub]

import os
import urllib
from time import *
from colored import *

def upgrade():	
	print("[+] Checking repos for a new version. Please wait.")
	sleep(2)
	try:
		cu = urllib.urlopen("http://www.mediafire.com/?34s9oanijz4fh6c")  #im going to replace this link
		res = cu.read()
		if 'Fsecurity Framework 4.0.1' in res:
			print("[+] New version of \fsecurity framework\' is available.")
			sleep(2)
			print("[+] Download: http://www.mediafire.com/?34s9oanijz4fh6c") 
			print("[+] Starting browser. Please wait.")
			sleep(2)
			os.system('iceweasel http://www.mediafire.com/?34s9oanijz4fh6c')
			os.system('chrome http://www.mediafire.com/?34s9oanijz4fh6c')
		else:
			print("[-] No new version of \'fsecurity framework\' is available.\nThis is the latest version of \'fsecurity framework.\'")
		   	sleep(4)
	except(IOError):
		print("[-] Error Found: No internet connection. ")
	except KeyboardInterrupt:
		print""

#!/usr/bin/python

import os
from colored import *
from time import *

def credits():
	print fore.BLUE+'    FSECURITY FRAMEWORK v3.1.5\n'
	print '   Founder:   Enigma\t@enigma'
	print ' Developer:   Enigma\t@enigma'
	print 'Maintainer:   Breach\t@br3ach'+style.RESET 

	print '\n Website: http://www.fsecurity.org'

#Listening for 802.11 Probe Requests
#This allows us to see the names of the networks on the preferred network lists of our clients.
#enigma
#blacksec

from scapy.all import *
from colored import *
from time import *
print '%s Loading Probe Sniffer Module%s' % (fg(3), attr(0))
sleep(4)
print "\n\tProbe Sniffer [\033[1;31mnet/probesniffer\033[1;m] | * listens for 802.11 probe\n\t requests and prints. This module allows us to see the names\n\t of the networks on the preferred network lists of our clients.\n\n\tUsage: use [module]\n\t[IFACE] - network interface in monitor mode.\n"

try:
	interface = str(raw_input("%s[CMD-LINE]:[IFACE]: %s" % (fg(1), attr(0))))
	print (fore.LIGHT_BLUE+" IFACE:["+style.RESET + interface +fore.LIGHT_BLUE+"]"+style.RESET )
	probeReqs = []
	print '\n[+] Scanning for connections using \''+interface+'\''
	sleep(3)
	def sniffProbe(p):
		if p.haslayer(Dot11ProbeReq):
			netName = p.getlayer(Dot11ProbeReq).info
			if netName not in probeReqs:
				probeReqs.append(netName)
				print '[+] Detected New Probe Request: ' + netName
	sniff(iface=interface, prn=sniffProbe)
	
except KeyboardInterrupt:
	print (fore.BLUE+"\n\n[+] Interrupted by user. Terminating. \n"+style.RESET)
	sleep(2)
except Exception, error: #handle exceptions
    	#log(error)
    	print "[-] Error Found: "+ str(error)
    	print "[-] Error Found: "+interface+" not in monitor mode\n"

#script by printing out the source IP address and TTL of incoming packets.
#enigma
#fsecurity
import os
from colored import * 
from scapy.all import *
from time import *
def scapyscan():
	print '%s Loading Packet Sniffer Module%s' % (fg(3), attr(0))
	sleep(4)
	print "\n\tPacket Sniffer [\033[1;31mnet/scapyscan\033[1;m] | * automatically print out the source\n\t IP addresses. Also print Time To Live [TTL] of incoming packets.\n\n\tUsage: use net/scapyscan"
	print '\n[+] Receiving incoming packets'
	try:
		def testTTL(pkt):
			try:
				if pkt.haslayer(IP):
					ipsrc = pkt.getlayer(IP).src
					ttl = str(pkt.ttl)
					print '[+] Pkt Received From: '+ipsrc+' with TTL: ' \
					+ ttl
			except:
				pass
		def main():
			sniff(prn=testTTL, store=0)
		if __name__ == '__main__':
			main()
	except KeyboardInterrupt:
		print (fore.BLUE+"\n\n[+] Interrupted by user. Terminating. \n"+style.RESET)
		sleep(2)
	except Exception, error: #handle exceptions
			#log(error)
			print "[-] Error Found: "+ str(error)+"\n"
if __name__ == '__main__':
	scapyscan()

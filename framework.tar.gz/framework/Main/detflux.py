#Detecting Fast Flux Traffic with Scapy



import os
from colored import *
from time import *
from scapy.all import *
dnsRecords = {}
print '%s Loading Fast Flux Detector Module%s' % (fg(3), attr(0))
sleep(4)
print "\n\tFast Flux Detector [\033[1;31mweb/fastfluxdetect\033[1;m] | * this module print\n\t out all the domain names and how many unique IP addresses exist\n\t for each domain name.\n\n\tUsage: use [module]\n\t[PCAP] - packet capture file.\n"
try:
	def handlePkt(pkt):
		if pkt.haslayer(DNSRR):
			rrname = pkt.getlayer(DNSRR).rrname
			rdata = pkt.getlayer(DNSRR).rdata
			if dnsRecords.has_key(rrname):
				if rdata not in dnsRecords[rrname]:
					dnsRecords[rrname].append(rdata)
			else:
				dnsRecords[rrname] = []
				dnsRecords[rrname].append(rdata)
	def main():
		pkts = rdpcap(str(raw_input(fore.RED+'[CMD-LINE]:[PCAP]: '+style.RESET )))   #domain capture file

		for pkt in pkts:
			handlePkt(pkt)
		for item in dnsRecords:
			print " "
			print '[+] '+item+' has '+str(len(dnsRecords[item])) \
			+ ' unique IPs.'
	if __name__ == '__main__':
		main()
except KeyboardInterrupt:
	print (fore.BLUE+"\n\n[+] Interrupted by user. Terminating. \n"+style.RESET)
	sleep(2)
except Exception, error: #handle exceptions
	print "\n[-] Error Found: "+ str(error)+"\n"

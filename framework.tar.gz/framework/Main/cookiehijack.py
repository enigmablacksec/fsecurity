#Cookie Hijack Module
#fsecurity. Enigma - eenigma607@gmail.com

import mechanize
import cookielib
from os import *
import os
from colored import *
from time import *
def cookiehijack():	
	print '%s Loading Cookie Hijacker Module%s' % (fg(3), attr(0))
	sleep(4)
	print "\n\tCookie Hijacker [\033[1;31mnet/cookiehijack\033[1;m] | * print the cookies\n\t stored during the session. The attacker and the target should be\n\t on the same network. Only works on HTTP protocol. Use \'sslstrip\' first.\n\n\tUsage: use [module]\n\t[URL] - specify target url.\n"
	try:
		def printCookies(url):
				browser = mechanize.Browser()
				cookie_jar = cookielib.LWPCookieJar()
				browser.set_cookiejar(cookie_jar)
				page = browser.open(url)
				for cookie in cookie_jar:
					print cookie
				
		url = str(raw_input("%s[CMD-LINE]:[URL]: %s"%(fg(1), attr(0))))
		print (fore.LIGHT_BLUE+"URL:[ "+style.RESET+url+fore.LIGHT_BLUE+']'+style.RESET)
		sleep(2)
		print '\n[+] Locating \'cookies\' from '+'\''+url+'\''
		sleep(3)
		printCookies(url)

	except KeyboardInterrupt:
		print (fore.BLUE+"\n\n[+] Interrupted by user. Terminating. \n"+style.RESET)
		sleep(2)
	except Exception, error: #handle exceptions
			#log(error)
			print "[-] Error Found: "+ str(error)+"\n"
if __name__=='__main__':
    cookiehijack()

#Wired/ Wireless Traffic Sniffer
#fsecurity. Enigma - eenigma607@gmail.com

import os
from time import *
from colored import *
from scapy.all import *
print '%s Loading Traffic Sniffer Module%s' % (fg(3), attr(0))
sleep(4)
print "\n\tNetwork Sniffer [\033[1;31mnet/networksniffer\033[1;m] | * this module scan for\n\t traffic that includes the 802.11 Probe Requests looking for\n\t networks, 802.11 Beacon Frames indicating traffic, and a DNS\n\t and TCP packet.\n\n\tUsage: use [module]\n\t[IFACE] - interface in monitor mode.\n"
try:
	def pktPrint(pkt):
		if pkt.haslayer(Dot11Beacon):
			print '[+] Detected 802.11 Beacon Frame'
		elif pkt.haslayer(Dot11ProbeReq):
			print '[+] Detected 802.11 Probe Request Frame'
		elif pkt.haslayer(TCP):
			print '[+] Detected a TCP Packet'
		elif pkt.haslayer(DNS):
			print '[+] Detected a DNS Packet'
	interface =str(raw_input("%s[CMD-LINE]:[IFACE]: %s" % (fg(1), attr(0))))	
	conf.iface = interface
	print '\n[+] Starting network sniffing using \''+interface+'\''
	sniff(prn=pktPrint)
except KeyboardInterrupt:
	print (fore.BLUE+"\n\n[+] Interrupted by user. Terminating. \n"+style.RESET)
	sleep(2)
except Exception, error: #handle exceptions
		print "[-] Error Found: "+ str(error)

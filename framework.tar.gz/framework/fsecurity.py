
#!/usr/bin/python

#						        FSECURITY FRAMEWORK				                              	#
#                 (c) fsecurity.org  http://www.fsecurity.org                                	 	#
#    Licensed under the GNU General Public License Version 2                      	# 
#                                                                                                              	#
#    FSECURITY Framework is free software;   you can redistribute it            	#
#    and/or modify it under the terms of the GNU General Public License       	#
#    as published by the Free Software Foundation; either version 2             		#
#    of the License, or any later version.                                                      	#
#																												 	#
#    FSECURITY Framework is distributed in the hope that it will be useful,     	#
#    but WITHOUT ANY WARRANTY; without even the implied warranty of      	#
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   		#
#    GNU General Public License for more details.                                         	#


import os
import sys
import shutil
sys.path.append("usr/share/fsecurity")
import readline			
#python2.7/bin/dist-upgrade
from socket import *
from time import *
from nmap import *
from mechanize import *
from colored import *											
from threading import *
#framework/Main/core
from Main.core import modules
from Main.core import banner2
from Main.core import upgrade
from Main.core import help
from Main.core import version
from Main.core import nmodules
from Main.core import credits
from Main.core import about

print fore.YELLOW+"Loading.."+style.RESET

print '\033[1;31m\nWaiting for a script kiddie to piss off. Please wait.\n\033[1;m '
troll = str(raw_input("")) #troll level: GOD
os.system("clear")

def main():
	try:
		user_input = ('%s[CMD-LINE] %s' % (fg(1), attr(0)))
		user_input += ": "		
		terminal = raw_input(user_input)
		#CORE COMMANDS
		if terminal[0:3] =='use':	
			if terminal[4:20] =='net/cookiehijack':
				os.system('python Main/cookiehijack.pyc')
				main()	
			elif terminal[4:27] =='wifi/sniffhidden':
				os.system('sudo python Main/sniffhidden.pyc')
				main()
			elif terminal[4:20] =='net/ftpscanner':
				os.system('sudo python Main/ftpscanner.pyc')
				main()		
			elif terminal[4:20] =='net/nmapinteg':
				os.system('python Main/nmapinteg.pyc')
				main()			
			elif terminal[4:27] =='net/scapyscan':
				os.system('sudo python Main/scapyscan.pyc')				
				main()	
			elif terminal[4:28] =='server/servercomprom':
				os.system('sudo python Main/servercomprom.pyc')
				main()
			elif terminal[4:29] =='net/probesniffer':
				os.system('sudo python Main/sniffprobes.pyc')
				main()
			elif terminal[4:30] =='file/zipfilecracker':
				os.system('sudo python Main/zipcracker.pyc')
				main()
			elif terminal[4:31] =='web/anonbrowser':
				os.system('sudo python Main/anonweb.pyc')
				main()
			elif terminal[4:32] =='wifi/creditcardsniff':
				os.system('sudo python Main/creditcard.pyc')
				main()
			elif terminal[4:33] =='web/confickerdetect':
				os.system('sudo python Main/detdomain.pyc')
				main()
			elif terminal[4:33] =='web/fastfluxdetect':
				os.system('sudo python Main/detflux.pyc')
				main()
			elif terminal[4:34] =='web/iplocate':
				os.system('sudo python Main/ip-locator.pyc')
				main()
			elif terminal[4:35] =='net/networksniffer':
				os.system('sudo python Main/netsniff.pyc')
				main()
			else:
				print fore.BLUE+"[-] No such module. Type \'show modules\' to view modules."+style.RESET
				main()	
	
			main()
		elif terminal[0:12] =='upgrade':
			upgrade.upgrade()
			main()
		elif terminal[0:10] =='version':
			version.version()
			main()
		elif terminal[0:12] =='help':
			help.help()
			main()
		elif terminal[0:12] =='show modules':
			modules.modules()
			main()
		elif terminal[0:13] =='show updates':
			nmodules.nmodules()
			main()		
		elif terminal[0:7] =='clear':
			os.system('clear')
			main()
		elif terminal[0:5] =='clean':
			os.system('sudo bash  Main/core/bash/cleaner.sh')
			main()
		elif terminal[0:9] =='credits':
			credits.credits()
			main()
		elif terminal[0:14] =='about':
			about.about()
			main()
		elif terminal[0:54] =='monitor on':
			os.system('sudo bash Main/core/bash/monitorenabled.sh')  
			main()
		elif terminal[0:55] =='monitor off':
			os.system('sudo bash Main/core/bash/monitordisabled.sh')  
			main()
		elif terminal[0:56] =='ifconfig':
			print " "
			os.system('sudo ifconfig')
			main()
		elif terminal[0:57] =='iwconfig':
			print " "
			os.system('sudo iwconfig')
			main()
		elif terminal[0:58] == 'banner':
			os.system('sudo bash Main/headers/header.sh')
			main()
		elif terminal[0:61] == 'download':
			os.system('sudo bash Main/core/bash/download.sh')
			main()
		elif terminal[0:6] =='exit':
			exit()
			try:
				# kill anything python running on 80
				kill_proc("80","python")
                # kill anything on 443 which is generally a rogue listener
				kill_proc("443", "ruby")
				os.system('clear')
			except: pass
		else :
			print fore.BLUE+"[-] No such command:"+style.RESET,terminal
			main()
	
	except KeyboardInterrupt:
		print  ('\n\n'+fore.BLUE+'[+] Terminating framework session. Please wait.\n'+style.RESET)
		sleep(3)
		os.system('clear');
		exit()
def start():
	os.system('sudo bash Main/headers/header.sh')
	main()
if __name__=='__main__':
    start()
